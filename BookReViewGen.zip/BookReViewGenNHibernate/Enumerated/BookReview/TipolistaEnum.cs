
using System;

namespace BookReViewGenNHibernate.Enumerated.BookReview
{
public enum TipolistaEnum { favorito=1, pendiente=2, acabado=3 };
}
