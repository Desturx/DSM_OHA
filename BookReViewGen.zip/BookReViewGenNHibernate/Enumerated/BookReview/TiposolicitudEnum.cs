
using System;

namespace BookReViewGenNHibernate.Enumerated.BookReview
{
public enum TiposolicitudEnum { pendiente=1, aceptado=2, rechazado=3 };
}
