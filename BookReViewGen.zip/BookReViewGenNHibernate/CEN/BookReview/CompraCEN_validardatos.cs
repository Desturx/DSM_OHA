
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using BookReViewGenNHibernate.Exceptions;
using BookReViewGenNHibernate.EN.BookReview;
using BookReViewGenNHibernate.CAD.BookReview;


/*PROTECTED REGION ID(usingBookReViewGenNHibernate.CEN.BookReview_Compra_validardatos) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace BookReViewGenNHibernate.CEN.BookReview
{
public partial class CompraCEN
{
public void Validardatos (int p_oid)
{
        /*PROTECTED REGION ID(BookReViewGenNHibernate.CEN.BookReview_Compra_validardatos) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Validardatos() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
